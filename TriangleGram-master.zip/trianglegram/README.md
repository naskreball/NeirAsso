# TriangleGram
![Клиент Telegram на основе библиотеки telethon с гибридным шифрованием. Полностью написан на Python](https://notabug.org/Black_Triangle/TriangleGram/raw/999d858328c512bd8d6f458955a998333e6b2231/priv.jpg)

Клиент Telegram на основе библиотеки telethon с гибридным шифрованием. Полностью написан на Python

### Зависимости:

`pip3 install -r requirements.txt`

`sudo apt-get install python3-tk`

Запустить фаил `1.py`и следовать инструкциям программы.

## Видео инструкция: https://www.youtube.com/watch?v=LADJTDajw0E
Ветки приветствуються

## Поддержать автора:

* Bitcoin: 1AWBMoeV8UEybQi4QrQMmeFX1sXvRLDeCn

* Ethereum: 0xB151c82A264eF0EA848c120444173658BFA18Cf9

* DASH: XcNtFGW1ydGLudvTPWoBvPZZxG844EvksR

* Zcash: t1hCJwasRozdkoaK9HLpngoEVPQhEZpxdFT

* Monero: 41iNuQsc6GjZofH3XkKwNYVSXVsrjipfVjjNR3nbsL5XjJMFTfykW1T6CkYz1StdXH2t8dhnjUTT9FwEPpbsFVxjHuuYabQ

* Litecoin: LNpw5QS5fvH1NW5AMp35zzMs1FYKuAUuPP

* Bitcoin Cash: qrs29h849m9vj02ljd2utf6g7e7hxnntqvkhz8r8u3

* Ethereum Classic: 0xc20a61Ec5765aC0059D6e85f069B440889EBfcC5

